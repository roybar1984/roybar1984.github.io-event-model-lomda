import React, { useState, useEffect } from "react";
import "./MouseEventConteiner.css";
// import OpeningExamplesContainer from "./containers/openingExamplesContainer/OpeningExamplesContainer";
// import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import {Markup} from "interweave";
import CenteredText from "../CenteredText/CenteredText"
import { BrowserRouter as Router, Route, Switch, useParams} from "react-router-dom";
import NextAndBackButtons from "./../../components/nextAndBackButtons/NextAndBackButtons"


function MouseEventConteiner(props) {
  return (
    <div className="mouse-event-container">
        <CenteredText Data={props.Data} page={props.page} array={props.array}/>
        <div className="delay-display-btn">
        <NextAndBackButtons back={props.back} typeNext="route" typeBack="route" next="event-types/mouse-events" />
        </div>
        {/* <div>hii</div> */}
      {/* אנימציה */}
      {/* <Button handleClick={handleClickNext} buttonText="בואו נגלה" /> */}
    </div>
  );
}

export default MouseEventConteiner;

import React, { useState, useEffect } from "react";
import gsap from "gsap";
import { Markup } from "interweave";
import PlusBtn from "../../components/PlusBtn/PlusBtn";
import Button from "./../../components/Button/Button";
import "./TextDisplayWithBtn.css";
import { useHistory } from "react-router-dom";
import NextAndBackButtons from "./../../components/nextAndBackButtons/NextAndBackButtons";

function TextDisplayWithBtn(props) {
  let history = useHistory();
  const [clickNum, setClickNum] = useState(0);
  const [linesToShow, setLinesToShow] = useState([]);

  useEffect(() => {
    setLinesToShow((prevState) => [...prevState, clickNum]);
  }, [clickNum]);

  useEffect(() => {
    console.log(linesToShow.length);
    gsap.timeline().from(`.delay-text${linesToShow.length}`, {
      ease: "sine",
      duration: 0.75,
      delay: 0.2,
      opacity: 0,
    });
  }, [linesToShow]);

  // gsap.to(`.number${props.part}`, {
  //   ease: "sine",
  //   duration: 0.5,
  //   border:"0.6vh solid rgba(151,225,135,1)"
  //   // background:"linear-gradient(90deg, rgba(151,225,135,1) 0%, rgba(180,221,123,1) 15%, rgba(213,216,109,1) 32%, rgba(251,210,92,1) 52%, rgba(231,162,143,1) 67%, rgba(212,117,190,1) 81%, rgba(187,55,254,1) 100%)"
  // });

  function handleClick(event) {
    if (clickNum < props.maxClicksNum) {
      setClickNum((prevState) => (prevState = prevState + 1));
    }
    if (props.isEventListener) {
      gsap.to(".title", 0, { y: -45, ease: "ease" });
    }
  }

  function handleOver(event) {
    gsap.to(".cls-2", 0, { fill: " url(#linear-gradient-3)" });
    gsap.to(".cls-1", 0, { stroke: " url(#linear-gradient-3)" });
  }

  function handleLeave(event) {
    gsap.to(".cls-2", 0, { fill: " url(#linear-gradient-2)" });
    gsap.to(".cls-1", 0, { stroke: " url(#linear-gradient-2)" });
  }

  function handleClickNext(event) {
    history.push("/event-types");
  }

  gsap.to(".delay-display-btn", {
    opacity: 1,
    delay: 1,
    duration: 1,
    ease: "spin",
  });

  return (
    <div>
      {props.isEventListener ? (
        <p className="title title-9">{props.Data[props.page].title}</p>
      ) : (
        ""
      )}
      <div className="text-btn-container">
        <div className="text-container">
          {linesToShow.map((line, index) => {
            return (
              <div key={index} className="paragrapghs">
                <Markup content={props.Data[props.page].text[line]} />
              </div>
            );
          })}
        </div>
        {clickNum < props.maxClicksNum ? (
          <PlusBtn
            handleLeave={handleLeave}
            handleOver={handleOver}
            handleClick={handleClick}
          />
        ) : !props.isEventListener ? (
          <div>
            <div className="delay-display-btn">
              <Button
                className="start-btn"
                handleClick={handleClickNext}
                buttonText="יאללה נתחיל"
              />
            </div>
          </div>
        ) : (
          <div></div>
        )}
      </div>
      {props.isEventListener && clickNum === props.maxClicksNum ? (
        <div className="delay-display-btn">
          <NextAndBackButtons typeNext="route" />
        </div>
      ) : (
        <div></div>
      )}
    </div>
  );
}

export default TextDisplayWithBtn;

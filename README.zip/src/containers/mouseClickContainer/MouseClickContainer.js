// MouseClickContainer

import React, { useState, useEffect } from "react";
import "./MouseClickContainer.css";
import BackgroundExamples from "../../components/backgroundExamples/BackgroundExamples";
import EventsExamples from "./../../components/eventsExamples/EventsExamples";

// import OpeningExamplesContainer from "./containers/openingExamplesContainer/OpeningExamplesContainer";
// import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
// import {Markup} from "interweave";
import NextAndBackButtons from "./../../components/nextAndBackButtons/NextAndBackButtons";
import CenteredText from "../CenteredText/CenteredText"

function MouseClickContainer(props) {
  const [clicksCount, setClicksCount]= useState(1);
  const [placesArray, setPlacesArray]=useState([
    {
      back:"event-types/mouse-events", 
  next:""
},
{
  back:"", 
  next:"event-types/mouse-events"
}
  ]);
  return (
    <div className="mouse-click-container">
        <div>654</div>
      {/* <NextAndBackButtons typeNext="noRoute" typeBack="route" back="intro" next="event-types/mouse-events" /> */}
    <EventsExamples examplePart={clicksCount}/>
    </div>
  );
}

export default MouseClickContainer;

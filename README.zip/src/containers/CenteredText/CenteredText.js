import gsap from "gsap";
import React, { useEffect } from "react";
import "./CenteredText.css";
import { Markup } from "interweave";
import Heart from "./../../svg/heart.svg";
import TextWithBall from "./../../components/TextWithBall/TextWithBall";

//added the part of checking if is array. for mouse events. need the prop of array cfrom component that calls this one!

function CenteredText(props) {
//   const mouseEventsTl = gsap.timeline();
//   useEffect(() => {
//     if (props.array) {
//       console.log(777);
//       mouseEventsTl.to(".centered-text-container", {
//         y: -80,
//         duration: 2,
//         ease: "spin",
//         delay: 1,
//       });
//       mouseEventsTl.to(
//         ".delay-show",
//         {
//           opacity: 1,
//           duration: 2,
//           ease: "spin",
//           // delay: 1.5,
//         },
//         "+=1"
//       );
//       mouseEventsTl.to(
//         ".delay-show",
//         {
//           opacity: 1,
//           duration: 1,
//           ease: "spin",
//         },
//         "+=1"
//       );
//       mouseEventsTl.to(
//         ".delay-show",
//         {
//           opacity: 1,
//           duration: 1,
//           ease: "spin",
//         },
//         "+=1"
//       );
//       mouseEventsTl.to(".delay-display-btn", {
//         opacity: 1,
//         duration: 1,
//         ease: "spin",
//       });
//       //   gsap.to(".centered-text-container", {
//       //     y: -90,
//       //     duration: 3,
//       //     ease: "spin",
//       //     delay: 1.5,
//       //   });
//     }
//   }, []);

  return (
    <div className="centered-text-container">
      <p className="main-title title">{props.Data[props.page].title}</p>
      <div className="centered-text">
        {props.array ? (
          <div className="text-with-examples-container">
            <Markup content={props.Data[props.page].text[0]} />
            <TextWithBall Data={props.Data} page={props.page} />

            {/* component of text that apears with a small ball anomation */}
            {/* <TextWithBall /> */}
            {/* <div className="mouse-events-contaier delay-show"> */}
            {/* {itemsToShow.map((item, index) => {
                     mouseEventsTl.to(`.delay-show${textNum}`, {
                        opacity: 1,
                        duration: 2,
                        ease: "spin",
                      }, "+=1");
            return (
                // className={`${props.backClass} cls-2-btn btns text-btns ${props.className}`}

              <div key={index} className={`paragrapghs delay-show delaw-show-p${props.textNum}`}>
                <Markup content={props.Data[props.page].text[item]} />
              </div>
            );
          })} */}
            {/* <div>
                <Markup content={props.Data[props.page].text[1]} />
              </div>
              <div>
                <Markup content={props.Data[props.page].text[2]} />
              </div>
              <div>
                <Markup content={props.Data[props.page].text[3]} />
              </div>
              <div>
                <Markup content={props.Data[props.page].text[4]} />
              </div>
              <div>
                <Markup content={props.Data[props.page].text[5]} />
              </div>
              <div>
                <Markup content={props.Data[props.page].text[6]} />
              </div>
            </div> */}
          </div>
        ) : (
          <Markup content={props.Data[props.page].text} />
        )}
      </div>
    </div>
  );
}

export default CenteredText;

import React, { useState, useEffect } from "react";
import "./BackgroundExamples.css";
import OpeningEventsExamples from "./../openingEventsExamples/OpeningEventsExamples";
import { gsap,} from "gsap";


function BackgroundExamples(props) {
  const changeBorder = () => {
    props.setDidOpenAll((prevState) => prevState + 1);
    gsap.to(`.number${props.part}`, {
        ease: "sine",
        duration: 0.5,
        border:"0.6vh solid rgba(151,225,135,1)"
        // background:"linear-gradient(90deg, rgba(151,225,135,1) 0%, rgba(180,221,123,1) 15%, rgba(213,216,109,1) 32%, rgba(251,210,92,1) 52%, rgba(231,162,143,1) 67%, rgba(212,117,190,1) 81%, rgba(187,55,254,1) 100%)"
      });
  };

  return (
        <div className={`BackgroundExamples number${props.part}`}>
          <OpeningEventsExamples
            part={props.part}
            changeBorder={changeBorder}
          />
        </div>
  );
}

export default BackgroundExamples;

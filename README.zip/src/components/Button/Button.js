import React from "react";
import "./Button.css";
import gsap from "gsap";

function Button(props) {
  return (
    <div
      onClick={props.handleClick}
      className={`${props.backClass} cls-2-btn btns text-btns ${props.className}`}
    >
      {props.buttonText}
    </div>
  );
}

export default Button;

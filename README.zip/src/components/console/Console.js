// Console

import React, { useState, useEffect, useRef } from "react";
import "./Console.css";
import { Markup } from "interweave";

// import OpeningEventsExamples from "./../openingEventsExamples/OpeningEventsExamples";
import { gsap } from "gsap";

function Console(props) {
    const bottomRef = useRef();
    const scrollToBottom = () => {
        bottomRef.current.scrollTop = bottomRef.current.scrollHeight - bottomRef.current.clientHeight;
    };

    useEffect(() => {
        scrollToBottom();
    }, [props.actionsArray]);

  return (
    <div className="console" ref={bottomRef} style={{width:`${props.width}`, height:`${props.height}`}} >
      {props.actionsArray.map((text, index) => (
        //   props.actionsArray[index]
        <Markup key={index} content={props.actionsArray[index]}  />
      ))}
    </div>
  );
}

export default Console;

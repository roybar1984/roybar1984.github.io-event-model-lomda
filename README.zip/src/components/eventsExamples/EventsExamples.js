import React, { useState, useEffect } from "react";
import "./EventsExamples.css";
import { gsap } from "gsap";
import { Markup } from "interweave";
import Console from "./../console/Console";
// import NextAndBackButtons from "./../../components/nextAndBackButtons/NextAndBackButtons";
// import CenteredText from "../CenteredText/CenteredText"

function EventsExamples(props) {
  const [actionsArray, setActionsArray] = useState([]);

  const handelMouseDown = () => {
    setActionsArray((prevState) => [
      ...prevState,
      '<p class="console-text">mousedown</p>',
    ]);

    gsap.to(".mouse-down", {
      ease: "sine",
      duration: 0.25,
      background:
        "linear-gradient(90deg, rgba(255,23,68,1) 0%, rgba(223,92,255,1) 52%, rgba(92,184,209,1) 100%)",
    });
    gsap.to(".color-of-click", {
      ease: "sine",
      duration: 0.25,
      width: "40%",
      background:
        "linear-gradient(90deg, rgba(255,23,68,1) 0%, rgba(223,92,255,1) 52%, rgba(92,184,209,1) 100%)",
    });
  };
  const handelhover = () => {
    if(props.examplePart === 2) {
        setActionsArray((prevState) => [
            ...prevState,
            '<p class="console-text">mouseover</p>'
          ]);
      }
    gsap.to(".exampls-ball", {
      ease: "sine",
      duration: 0.25,
      y: -6,
    });
  };
  const handleMover = () => {
    if(props.examplePart === 2) {
        setActionsArray((prevState) => [
            ...prevState,
            '<p class="console-text">mousemove</p>'
          ]);
      }
  };

  const handleout = () => {
      if(props.examplePart === 2) {
        setActionsArray((prevState) => [
            ...prevState,
            '<p class="console-text">mouseout</p>',
            "<hr />",
          ]);
      }
    gsap.to(".exampls-ball", {
      ease: "sine",
      duration: 0.25,
      y: 6,
    });
  };

  const onTrashClick = () => setActionsArray([]);

  const handelMouseUp = () => {
    if (props.examplePart === 1) {
      setActionsArray((prevState) => [
        ...prevState,
        '<p class="console-text">mouseup</p>',
        '<p class="console-text">click</p>',
        "<hr />",
      ]);
      gsap.to(".mouse-down", {
        ease: "sine",
        duration: 0.7,
        background: "#ffffff8a",
      });
      gsap.to(".mouse-up", {
        ease: "sine",
        duration: 0.25,
        background:
          "linear-gradient(90deg, rgba(255,23,68,1) 0%, rgba(223,92,255,1) 52%, rgba(92,184,209,1) 100%)",
      });
      gsap.to(".mouse-up", {
        ease: "sine",
        duration: 0.7,
        background: "#ffffff8a",
        delay: 0.55,
      });
      gsap.to(".color-of-click", {
        ease: "sine",
        duration: 0.25,
        width: "100%",
      });
      gsap.to(".color-of-click", {
        ease: "sine",
        duration: 0.9,
        delay: 0.55,
        width: "0%",
        // background: "#ffffff8a",
      });
    }
  };

  return (
    <div className="event-examples">
      <svg
        viewBox="0 0 152.66 152.66"
        className="exampls-ball button"
        onMouseUp={handelMouseUp}
        onMouseDown={handelMouseDown}
        onMouseEnter={handelhover}
        onMouseLeave={handleout}
        onMouseMove= {handleMover}
      >
        <defs>
          <radialGradient
            id="radial-gradient"
            cx="71.57"
            cy="85.39"
            fx="-39.58415570029722"
            fy="115.93390435929376"
            r="115.28"
            gradientTransform="translate(149.45 4.12) rotate(83.26) scale(1 1.02)"
            gradientUnits="userSpaceOnUse"
          >
            <stop offset="0" stopColor="#5cb8d1" />
            <stop offset="0.04" stopColor="#6cadd7" />
            <stop offset="0.26" stopColor="#be73f4" />
            <stop offset="0.37" stopColor="#df5cff" />
            <stop offset="0.4" stopColor="#e158f5" />
            <stop offset="0.47" stopColor="#e54eda" />
            <stop offset="0.55" stopColor="#ed3eae" />
            <stop offset="0.64" stopColor="#f72873" />
            <stop offset="0.71" stopColor="#ff1744" />
            <stop offset="0.74" stopColor="#e81747" />
            <stop offset="0.87" stopColor="#851755" />
            <stop offset="0.93" stopColor="#5e175b" />
          </radialGradient>
        </defs>
        <g id="Layer_2" data-name="Layer 2">
          <g id="elements">
            <circle
              className="ball-background"
              cx="76.33"
              cy="76.33"
              r="76.33"
            />
          </g>
          <g id="text">
            <text className="event-text" transform="translate(37.73 81.11)">
              לחצו עליי
            </text>
          </g>
        </g>
      </svg>

      {props.examplePart === 1 && (
        <div className="scales-conteiner">
          <div className="click scale">
            <div className="color-of-click"></div>
            <p className="click-text">click</p>
          </div>
          <div className="mouse-down scale">mousedown</div>
          <div className="mouse-up scale">mouseup</div>
        </div>
      )}

      <div className="console-div">
        <Console actionsArray={actionsArray} width="23vw" height="30vh" />
        <svg
          viewBox="0 0 49.34 49.34"
          className="teash button"
          onClick={onTrashClick}
        >
          <defs>
            <linearGradient
              id="linear-gradient"
              x1="-1336.12"
              y1="1317.09"
              x2="-1286.79"
              y2="1317.09"
              gradientTransform="translate(1426.26 1245.4) rotate(86.18)"
              gradientUnits="userSpaceOnUse"
            >
              <stop offset="0.08" stopColor="#17d2ff" />
              <stop offset="0.13" stopColor="#25caff" />
              <stop offset="0.22" stopColor="#49b5ff" />
              <stop offset="0.35" stopColor="#8492ff" />
              <stop offset="0.5" stopColor="#d463ff" />
              <stop offset="0.52" stopColor="#df5cff" />
              <stop offset="0.78" stopColor="#f2328e" />
              <stop offset="0.96" stopColor="#ff1744" />
            </linearGradient>
            <linearGradient
              id="linear-gradient-2"
              x1="24.67"
              y1="20.13"
              x2="24.67"
              y2="39"
              gradientUnits="userSpaceOnUse"
            >
              <stop offset="0.08" stopColor="#5cb8d1" />
              <stop offset="0.1" stopColor="#65b1d4" />
              <stop offset="0.22" stopColor="#998de7" />
              <stop offset="0.33" stopColor="#bf72f4" />
              <stop offset="0.41" stopColor="#d662fc" />
              <stop offset="0.47" stopColor="#df5cff" />
              <stop offset="0.76" stopColor="#f2328e" />
              <stop offset="0.96" stopColor="#ff1744" />
            </linearGradient>
          </defs>
          <title>trash-btn</title>
          <g id="Layer_2" data-name="Layer 2">
            <g id="elements">
              <circle className="cls-1" cx="24.67" cy="24.67" r="24.02" />
              <path
                className="cls-2"
                d="M35.09,18.45a.83.83,0,0,0,.78-1.14A5.32,5.32,0,0,0,30.94,14h-1a4.47,4.47,0,0,0-4.35-3.64H23.77A4.46,4.46,0,0,0,19.43,14h-1a5.33,5.33,0,0,0-4.94,3.34.84.84,0,0,0,.79,1.14ZM23.77,12h1.79a2.76,2.76,0,0,1,2.62,2h-7A2.76,2.76,0,0,1,23.77,12Z"
              />
              <path
                className="cls-3"
                d="M16.55,36.66A2.53,2.53,0,0,0,19.07,39h11.2a2.53,2.53,0,0,0,2.52-2.34L34,20.13H15.38ZM27,24.63a.84.84,0,1,1,1.67.08l-.44,9a.85.85,0,0,1-.84.8.84.84,0,0,1-.84-.88Zm-5.48-.8a.84.84,0,0,1,.88.8l.45,9a.84.84,0,0,1-1.68.08l-.45-9a.85.85,0,0,1,.8-.88Z"
              />
            </g>
          </g>
        </svg>
      </div>
    </div>
  );
}

export default EventsExamples;

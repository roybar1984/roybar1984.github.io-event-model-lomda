import React, { useState, useEffect } from "react";
import "./TextWithBall.css";
import { Markup } from "interweave";
import gsap from "gsap";

function TextWithBall(props) {
  const mouseEventsExamples = props.Data[props.page].text.map((item) => {
    return item;
  });

  const mouseEventsTl = gsap.timeline();
  useEffect(() => {
    console.log(777);
    mouseEventsTl.to(".centered-text-container",1, {
      y: -80,
      duration: 2,
      ease: "spin",
      delay: 1,
    });
    mouseEventsTl.from(
      ".mouse-events-contaier",
      { width: "50%", duration: 2, ease: "spin", delay: 1 },"-=5"
    );
    mouseEventsTl.to(
      ".delay-show",
      {
        opacity: 1,
        duration: 2,
        ease: "spin",
      },
      "+=1"
    );
    mouseEventsTl.to(
      ".delay-show",
      {
        opacity: 1,
        duration: 1,
        ease: "spin",
      },
      "+=1"
    );
    mouseEventsTl.to(".delay-show", {
      opacity: 1,
      duration: 1,
      ease: "spin",
    });
    mouseEventsExamples.forEach((element, index) => {
      if (index !== 0) {
        let tl = gsap.timeline();
        tl.to(`.delay-show-item${index}`, { opacity: 1, duration: 1 });
        mouseEventsTl.add(tl);
      }
    });
    mouseEventsTl.to(".delay-display-btn", {
      opacity: 1,
      duration: 1,
      ease: "spin",
    });
    //   gsap.to(".centered-text-container", {
    //     y: -90,
    //     duration: 3,
    //     ease: "spin",
    //     delay: 1.5,
    //   });
  }, []);

  console.log(mouseEventsExamples);

  return (
    <div className="mouse-events-contaier delay-show">
      {mouseEventsExamples.map((item, index) => {
        //   {let tl= gsap.timeline();
        //     tl.to(`.delay-show-item${index}`, {opacity:1, duration:1})
        //     mouseEventsTl.add(tl);
        // }
        if (index !== 0) {
          return (
            <div
              className={`delay-show-items delay-show-item${index}`}
              key={index}
            >
              {" "}
              <Markup content={props.Data[props.page].text[index]} />
            </div>
          );
        }
      })}
    </div>
  );
}

export default TextWithBall;

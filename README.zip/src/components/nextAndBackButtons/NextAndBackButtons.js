import React, { useState, useEffect } from "react";
import "./NextAndBackButtons.css";
import Button from "./../../components/Button/Button";
import { gsap } from "gsap";
import { useHistory, useParams  } from "react-router-dom";

function NextAndBackButtons(props) {
  const history = useHistory();
  // const params= useParams();
  
  const handleBack= ()=>{
    history.push(`/${props.back}`);
    // history.push(`/${props.back}`);
  }
  const handleNext = ()=>{
    // <Link></Link>
    // if(props.typeNext==="route"){
      history.push(`/${props.next}`);
    // }

  }

  return (
    <div className="NextAndBackButtons">
        <Button className="prev-next-btn" handleClick={handleBack} buttonText="חזור" backClass="backClass" />
        <Button className="prev-next-btn" handleClick={handleNext} buttonText="המשך" />
    </div>
  );
}

export default NextAndBackButtons;

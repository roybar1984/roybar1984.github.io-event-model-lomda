import React, { useState } from "react";
import OpeningExamplesContainer from "./containers/openingExamplesContainer/OpeningExamplesContainer";
import Data from "./data/text.json";
import "./App.css";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import TextDisplayWithBtn from "./containers/TextDisplayWithBtn/TextDisplayWithBtn";
import CenteredText from "./containers/CenteredText/CenteredText";
import EventTypes from "./containers/eventTypes/EventTypes";
import MouseEventConteiner from "./containers/mouseEventConteiner/MouseEventConteiner";
import Heart from "./svg/heart.svg"
import MouseClickContainer from "./containers/mouseClickContainer/MouseClickContainer";

// import {Markup} from "interweave";

function App() {
  return (
    <div className="App">
      <Router>
        <Switch>
          <Route exact path="/">
            {/* <HomePage /> */}
          </Route>
          <Route path="/opening-examples">
            <OpeningExamplesContainer Data={Data} page={1} />
          </Route>
          <Route exact path="/intro">
            <TextDisplayWithBtn
              isEventListener={false}
              maxClicksNum={2}
              Data={Data}
              page={2}
            />
          </Route>
          <Route exact path="/event-types">
            <EventTypes Data={Data} page={3} />
          </Route>
          <Route exact path="/event-types/mouse-events">
            <MouseEventConteiner back={"event-types"} Data={Data} page={4} array = {true} />
          </Route>
          <Route path="/event-types/load-event">
            <CenteredText Data={Data} page={8}  />
            </Route>
          <Route path="/event-types/mouse-events/click">
            <MouseClickContainer Data={Data} page={5} />
          </Route>
          <Route path="/event-listeners">
            <TextDisplayWithBtn
              isEventListener={true}
              maxClicksNum={1}
              Data={Data}
              page={9}
            />
          </Route>
        </Switch>
      </Router>
    </div>
  );
}

export default App;
